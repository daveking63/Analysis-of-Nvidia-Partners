import glob, os
import shutil
import 
import unicodedata

pFileDir =  "C:/Research/Teuvonet/"

# Whole World Data
partnerFile = pFileDir + "nvidia_partners-world.txt"

# Read World Data for partners including name, types, competencies, levels, and addresses

with open(partnerFile) as f:
    partnerList = f.read()  
partnerListLines = partnerList.split("\n")

# Create type, competencies and level file for all partners worldwide

for line in partnerListLines[0:]:
    convertedLine = unicodedata.normalize('NFD', line).encode('ascii', 'ignore')
    lineItems = line.split('\t')
    #print('*****')
    partnerName = lineItems[0]
    pAddressLoc = len(lineItems) - 1
    partnerTandC = []
    for item in lineItems[1:pAddressLoc]:
        if item != '':
            itemTemp = item.strip(' ')
            lenItem = len(item)
            lenItemTemp = len(itemTemp)
            #print (partnerName, lenItem, item, lenItemTemp, itemTemp)
            pStr = partnerName + "\t" + itemTemp
            print(pStr)
            # next stage is to create a dictionary of these data
            # which is based on following list partnerTandC = partnerTandC + [itemTemp]
            # along with 
            
# Manually copy names, competencies, and levels then paste to Excel for checking
# then stored in:  "nvidia partner world type comp lvl.txt"
# and "nvidia partner world analysis.xlsx" which contains data analysis.
# Again, next stage will eliminate the manual process (after all errors have been corrected).  

# Create Address file from original partner World data in partnerFile

for line in partnerListLines[0:]:
    convertedLine = unicodedata.normalize('NFD', line).encode('ascii', 'ignore')
    lineItems = line.split('\t')
    partnerName = lineItems[0]
    pAddressLoc = len(lineItems) - 1
    partnerAddress = lineItems[pAddressLoc]
    #print(partnerAddress)
    pNameAndAddress = partnerName + '\t' + partnerAddress
    print(pNameAndAddress)
    
# Manually copy names and addresses printed in consol, paste to Excel for checking
# then stored in: "nvidia_partners-world Addresses.txt" and
# "nvidia partner world address with countries.xlsx"

partnerAddresses = pFileDir + "nvidia_partners-world Addresses.txt"

with open(partnerAddresses) as f:
    partnerAddressList = f.read()
partnerAddressLines = partnerAddressList.split("\n")

# Extracting Country names for each partner

lineCnt = 0
for line in partnerAddressLines[0:]:
    lineItems = line.split('\t')
    partnerName = lineItems[0]
    partnerAddress = lineItems[1]
    partnerAddTemp = partnerAddress.split(',')
    lenAdd = len(partnerAddTemp) - 1
    partnerCountry = partnerAddTemp[lenAdd].strip('"')
    partnerCountry = partnerCountry.strip(' ')
    #print(lineCnt, len(partnerAddTemp), partnerCountry, partnerAddTemp)
    printStr = partnerName + '\t' + partnerAddress + '\t' + partnerCountry
    print(printStr)
    lineCnt += 1